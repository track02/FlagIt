# FlagIt


A simple web extension checklist for flag collectors.


## TODO

Refactor code and package for submission.

Consider using individual pages and displaying flags alphabetically, 
this would allow larger flag images to be used on each page or breaking 
up the page into alphabetical sections.


## Other

Extension icon from: https://material.io/icons/

Current flag icons from: http://icondrawer.com/free.php.

Polyfill library added for Chrome support: https://github.com/mozilla/webextension-polyfill
