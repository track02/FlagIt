#include <iostream>
#include <vector>

class Shape {
	public:
	virtual void virt() { std::cout << "Parent Virtual Procedure Implementation\n";}
	virtual void pureVirt() = 0;

};

class Derived_Shape_A : public Shape {

	public:	
	virtual void pureVirt() override { std::cout << "Shape A - Overridden Pure\n";}

};

class Derived_Shape_B : public Shape {

	public:
	virtual void virt() override { std::cout << "Shape B - Overridden Virtual\n";}
	virtual void pureVirt() override {std::cout << "Shape B - Overridden Pure\n";}

};



int main() {


	Derived_Shape_A A_Shape;
	Derived_Shape_B B_Shape;

	A_Shape.virt();
	B_Shape.virt();
	A_Shape.pureVirt();
	B_Shape.pureVirt();


	std::cout << "Vector Access\n\n";
	std::vector<Shape*> shapeVec;

	shapeVec.push_back(&A_Shape);
	shapeVec.push_back(&B_Shape);

	shapeVec.at(0)->pureVirt();
	shapeVec.at(1)->pureVirt();

}
