Solutions to  exercises from Structure and Interpretation of Computer Programs (SICP)
